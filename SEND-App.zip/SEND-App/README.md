# SEND — Message Dispatch App

A single-file browser app for sending SMS and Email via Twilio, Microsoft Graph, and SMTP.

## Features
- 📱 **SMS** via Twilio REST API (browser-direct)
- 🔷 **Email** via Microsoft Graph (multi-mailbox, auto-fetch from tenant)
- 📧 **Email fallback** via SMTP (generates Node.js nodemailer snippet)
- 📎 **File attachments** (drag & drop, up to 25 MB, Graph only)
- 📨 **Email me the app** — sends the HTML source to yourself via Graph
- 🗂️ **Dispatch log** with status, provider, timestamp

## Quick Start
1. Open `messenger.html` in any modern browser (no server needed)
2. Click **⚙ Configure** and enter your credentials
3. Start sending

## Credential Setup

### Twilio (SMS)
1. Sign up at https://console.twilio.com
2. Copy your **Account SID** and **Auth Token**
3. Get a verified **From** phone number
4. Enter all three in ⚙ Configure → Twilio

### Microsoft Graph (Email)
1. Go to https://portal.azure.com → Azure Active Directory → App registrations
2. Register a new app
3. Under **API Permissions**, add:
   - `Mail.Send` — Application permission
   - `User.Read.All` — Application permission (for auto-fetch mailboxes)
4. Click **Grant admin consent**
5. Under **Certificates & secrets**, create a **Client Secret**
6. Copy your **Tenant ID**, **Client ID**, and **Client Secret**
7. Enter in ⚙ Configure → Microsoft Graph

### SMTP (Email fallback)
- Enter your SMTP host, port, username, password, and security setting
- Clicking Send generates a **Node.js nodemailer snippet** — copy and run it locally

## File Attachments (Graph)
- Drag & drop or click to browse
- Multiple files supported
- 25 MB total limit (Graph API limit)
- Attachments auto-clear after successful send

## Notes
- All credentials are stored in **browser localStorage** — never sent anywhere except to the respective APIs
- The app is fully self-contained — one `.html` file, no dependencies, no server
- SMTP cannot run directly in a browser (TCP limitation) — hence the snippet approach

## Tech Stack
- Vanilla HTML/CSS/JS
- Twilio Messages API
- Microsoft Graph API v1.0
- Node.js + nodemailer (SMTP snippet)
