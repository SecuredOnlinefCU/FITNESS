/**
 * SEND App — SMTP Backend Helper
 * Run this locally when you want to send via SMTP.
 *
 * Usage:
 *   npm install nodemailer express cors
 *   node smtp-server.js
 *
 * Then update the app to POST to http://localhost:3000/send
 */

const express  = require('express');
const nodemailer = require('nodemailer');
const cors     = require('cors');

const app = express();
app.use(cors());
app.use(express.json({ limit: '30mb' }));

// ── Configure your SMTP here ──
const transporter = nodemailer.createTransport({
  host: 'smtp.example.com',
  port: 587,
  requireTLS: true,
  auth: {
    user: 'YOUR_USERNAME',
    pass: 'YOUR_PASSWORD'
  }
});

app.post('/send', async (req, res) => {
  const { from, to, subject, text, attachments } = req.body;
  try {
    const info = await transporter.sendMail({
      from, to, subject, text,
      attachments: (attachments||[]).map(a => ({
        filename: a.name,
        content:  Buffer.from(a.base64, 'base64'),
        contentType: a.type
      }))
    });
    res.json({ ok: true, messageId: info.messageId });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.listen(3000, () => console.log('SMTP server running on http://localhost:3000'));
